import argparse
import hl7
from hl7apy.parser import parse_message
from hl7apy.core import Segment

if __name__ == "__main__":
	# Program your python Application from here
	parser = argparse.ArgumentParser()
	parser.add_argument( "filename")
	args = parser.parse_args()
	with open(args.filename, 'rb') as f:
		message = f.read()
	h = hl7.parse(message, encoding="latin1")
	print(h[2])
	print(h[1])
	print(type(h[1]))
	for item in h[1]:
		print(item)
	
	h2 = parse_message(message.decode("latin1"), validation_level=2)
	
	for segment in h2.children:
		if isinstance(segment, Segment):
			for attribute in segment.children:
				print(attribute, attribute.value)
	#parser = argparse.ArgumentParser(allow_abbrev=False)
	#parser.add_argument("--name", required = True, type = str, help = "your name")
	#args = parser.parse_args()
	#print()
	#print(f"Hello {args.name}!")
	#print()
