#! /usr/bin/env python3
"""Parse all specific APP parameters.

It also does a post-processing of some arguments in case the task_type
parameter is 'normal'.
"""
import logging
from argparse import Namespace

from biomed.auth import TokenAuth
from biomed.client import BiomedApiClient

from pipeline_tests.helpers.tests import launch_tests
from pipeline_tools.CWL_tools.biomed.biomed_upload_dir_get_id import upload_dir
from pipeline_tools.helpers.clean import clean_args
from pipeline_tools.helpers.download import download_data
from pipeline_tools.helpers.launch import initial_setup, run_script
from pipeline_tools.parsers._biomed_parser import is_normal_run
from pipeline_tools.parsers.python_parser import parser


def parse_args() -> Namespace:
    """Parse input arguments.

    After parsing them, perform different checks depending on the type of
    execution (if it's a normal or a test run).
    """
    # App-specific parameters
    parser.add_argument("--name", required=is_normal_run, type=str, help="Your name")
    args = parser.parse_args()

    if not is_normal_run:
        # Add here any processing performed only for TEST executions
        # Example: remove arguments that are not required for tests,
        # which will be passed as "None"
        args = clean_args(args)

    return args


def launch_app(api: BiomedApiClient, args: Namespace, test_file: str = None) -> None:
    """Launch main application.

    It has 4 main steps:
    1. Run an initial setup to make sure everything is OK before launching
    2. (OPTIONAL) Download required files/directories from biomed
    3. Build and execute the main command of the application
    4. (OPTIONAL) Upload directory with output files to biomed

    If a test file is provided, it will update input arguments with the ones found in the file.

    If it is a test execution, the 'upload_dir' function will be called with
    argument 'move_to_current' as True: that way, the generated output files
    will be moved to a directory to be compared later with another directory of
    previous files from the application.

    Args:
        api: connection with biomed API
        args: input arguments
        test_file: (OPTIONAL) file used when running a test to update input arguments from there

    Returns:
        None
    """
    args = initial_setup(args, test_file)

    # # OPTIONAL STEP: download data from biomed
    # data_dict, data_yaml = download_data(
    #     api=api,
    #     args=args,
    #     args_to_download=["array_file_id"],
    #     extensions=["csv"],
    #     secondary_extensions=["null"]
    # )

    # Step 1: Create the command you want to execute and run it
    cmd = f"{args.language_interpreter} {args.main_script} --name {args.name}"
    run_script(cmd=cmd, args=args)

    # # OPTIONAL STEP: upload output data to biomed
    # is_test = args.task_type.lower() != "normal"
    # upload_dir(api=api, dir_to_upload=args.out_dir, output_dir="", id_project=args.id_project, move_to_current=is_test)


def main():
    args = parse_args()

    # Redirect log messages to a file (it's important to set it before
    # BiomedApiClient in biomed-client version <= 1.5.0)
    # WARNING!! a 'mkdir' command has to be executed in Dockerfile to create
    # the logs_dir directory
    logging.basicConfig(
        level="INFO",
        format="%(asctime)s [%(levelname)s] -- %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        filename=f"{args.logs_dir}/launch.log"
    )

    # Authenticate with biomed-client
    api = BiomedApiClient(TokenAuth(token=args.token, refresh_token=args.refresh_token))

    # Launch normal/tests execution
    if is_normal_run:
        launch_app(api=api, args=args)
    else:
        launch_tests(api=api, args=args, launch_app=launch_app)


if __name__ == "__main__":
    main()
