# Template for a Biomed Application

[TOC]

This is a template repository with all the required files needed to deploy a
Python Biomed Application. You can fork this repository to avoid creating all
these files from scratch.

For more information, check the Confluence page [How to create a new
Application](https://madeofgenes.atlassian.net/wiki/spaces/ORP/pages/1644756993).

---

## Release Process

### Creating a new release

Read section `Create version in Bitbucket` of the following document:
[How to create a version of an application](https://madeofgenes.atlassian.net/wiki/spaces/ORP/pages/1545371662).

### Automatically build and deploy the docker image

The docker image is automatically deployed with [Bitbucket
pipelines](https://support.atlassian.com/bitbucket-cloud/docs/get-started-with-bitbucket-pipelines/)
once you [tag a
commit](https://support.atlassian.com/bitbucket-cloud/docs/repository-tags/)
from Bitbucket.

The variables defined in [bitbucket-pipelines.yml](./bitbucket-pipelines.yml)
come from a combination of [Workspace
Variables](https://support.atlassian.com/bitbucket-cloud/docs/variables-and-secrets)
and [Repository
variables](https://bitbucket.org/madeofgenes/biomed_app_template/admin/addon/admin/pipelines/repository-variables).

Since the tag is unique to the repository, you can't add the same tag to more
than 1 commit. To move an existing tag to another commit, you need to first
delete the tag using a terminal with the command `git push --delete origin
<tag_name>`, e.g. `git push --delete origin v0.0.1`.

---

## Work locally

To work with this repository locally in your computer, do the following for the setup:

```bash
# Clone this repository and enter it
git clone git@bitbucket.org:madeofgenes/biomed_app_template.git
cd biomed_app_template

# Setup the git submodules
git submodule init && git submodule update  # Use '--remote' in the update command 
                                            # if you want the latest changes
```

---

## Changelog

### v0.0.2

Released XX-XX-2020. Changes introduced:

* TODO

### v0.0.1

Released XX-XX-2020. Initial working version.
