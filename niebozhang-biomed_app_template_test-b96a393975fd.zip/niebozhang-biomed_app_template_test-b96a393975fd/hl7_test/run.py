import argparse
import datetime

import hl7
from hl7apy.parser import parse_message

p = argparse.ArgumentParser()
p.add_argument("filename")
args = p.parse_args()

with open(args.filename, "rb") as f:
    message = f.read()

# https://pypi.org/project/hl7/ library
h = hl7.parse(message, encoding="latin1")
print(h[3])
print(type(h))
print(h['PID'])
print(h['PID.F7'])
print(h['PID.F7.R1'])
print(h['PID.F7.R1.C1'])
print(h['PID.F7.R1.C1.S1'])

print("ended")

# https://pypi.org/project/hl7apy/ library
h2 = parse_message(message.decode("latin1"), validation_level=2)
print(h2.children)
print(h2.msh.value)
print(h2.msh.msh_9.value)
incoming_hl7 = {
    "type": h2.msh.msh_9.value,
    "client_app": h2.msh.msh_3.value,
    "client_fac": h2.msh.msh_4.value,
    "control_id": h2.msh.msh_10.value,
    "process_id": h2.msh.msh_11.value,
    # HL7-Python datetime.datetime object serialization
    "timestamp": datetime.datetime.strptime(h2.msh.msh_7.value, "%Y%m%d%H%M%S%f"),
    "hl7": h2
}
print(incoming_hl7)
#breakpoint()
